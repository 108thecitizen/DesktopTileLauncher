shiboken_library_soversion = "6.9"

version = "6.9.2"
version_info = (6, 9, 2, "", "")

__build_date__ = '2025-08-19T06:59:47+00:00'




__setup_py_package_version__ = '6.9.2'

